package com.example.add2num;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.Arrays;

public class zadacha3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zadacha3);
        Button btnGoToSecAct = (Button) findViewById(R.id.button3);


        View.OnClickListener oclBtnGoToSecAct = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(zadacha3.this, MainActivity.class);
                startActivity(intent);
            }
        };


        ImageView imageView = findViewById(R.id.imaa);
        imageView.setImageResource(R.drawable.eng);


        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);
        Button otpr1 = (Button) findViewById(R.id.button4);
        Button otpr2 = (Button) findViewById(R.id.button5);

        TextView text = (TextView) findViewById(R.id.textView4);
        String[] a = {"", "", "", ""};
        String[] a1 = {"", "да", "нет", "да"};

        View.OnClickListener onClickListener = new View.OnClickListener() {
            int over = -1;
            String a2 = "";

            @Override
            public void onClick(View view) {
                text.setText("");
                btnGoToSecAct.setEnabled(false);
                over += 1;
                if (over < 4) {
                    if (over == 0) {
                        imageView.setImageResource(R.drawable.cat);
                        otpr1.setText("CAT");
                        otpr2.setText("PYRO");
                    }
                    if (over == 1) {
                        imageView.setImageResource(R.drawable.index);
                        otpr1.setText("JOINER");
                        otpr2.setText("DOG");
                    }
                    if (over == 2) {
                        otpr1.setText("COLLIDER");
                        otpr2.setText("MINER");
                        imageView.setImageResource(R.drawable.collider);
                    }
                    switch (view.getId()) {
                        case R.id.button4:
                            a[over] = "да";
                            System.out.println(Arrays.deepToString(a));
                            break;

                        case R.id.button5:
                            a[over] = "нет";
                            System.out.println(Arrays.deepToString(a));
                            break;
                    }
                } else {


                    System.out.println(Arrays.deepToString(a));
                    System.out.println(Arrays.deepToString(a1));

                    if (a1[1] == a[1] && a1[2] == a[2] && a1[3] == a[3]) {
                        Intent intent = new Intent(zadacha3.this, Activity3.class);
                        intent.putExtra("hello", 333);
                        startActivity(intent);


                    } else {
                        if (a1[1] != a[1]) {
                            a2 += "Вы ответили Pyro, а надо было Cat";


                        }
                        if (a1[2] != a[2]) {
                            a2 += "\nВы ответили Joiner, а надо было Dog";


                        }
                        if (a1[3] != a[3]) {
                            a2 += "\nВы ответили Miner, а надо было COLLIDER";


                        }
                        text.setText(a2);
                        btnGoToSecAct.setText("повторить курс и вернуться");
                        btnGoToSecAct.setEnabled(true);

                    }
                }

            }

        };
        otpr1.setOnClickListener(onClickListener);
        otpr2.setOnClickListener(onClickListener);
    }
}

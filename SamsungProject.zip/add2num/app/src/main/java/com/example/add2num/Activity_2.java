package com.example.add2num;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Button btnGoToSecAct = (Button) findViewById(R.id.btnGoToMainAct);
        setTitle("CheckBox");
        View.OnClickListener oclBtnGoToSecAct = new View.OnClickListener()

        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(Activity_2.this, MainActivity.class);
                startActivity(intent);
            }
        };

        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);
        Button btnGoToSecAct2 = (Button) findViewById(R.id.button6);
        View.OnClickListener oclBtnGoToSecAct2 = new View.OnClickListener()

        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(Activity_2.this, prodo.class);
                startActivity(intent);
            }
        };

        btnGoToSecAct2.setOnClickListener(oclBtnGoToSecAct2);
    }
}
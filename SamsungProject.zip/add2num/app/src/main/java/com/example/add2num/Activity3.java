package com.example.add2num;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class Activity3 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Bundle arguments = getIntent().getExtras();
        Boolean a = false;
        Boolean a1 = false;
        Boolean a2 = false;

        if (arguments != null) {
            String name = arguments.get("hello").toString();
            System.out.println(name.length());

            if (name.length() == 1) {
                a = true;
            }
            if (name.length() == 2) {
                a1 = true;
            }
            if (name.length() == 3) {
                a2 = true;
            }
            }


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        Button btnGoToSecAct = (Button) findViewById(R.id.btnGoToMainAct);
        View.OnClickListener oclBtnGoToSecAct = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity3.this, MainActivity.class);
                startActivity(intent);

            }
        };
        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);

        Button zadacha11 = (Button) findViewById(R.id.zadacha1);
        Button zadacha12 = (Button) findViewById(R.id.zadacha2);
        Button zadacha13 = (Button) findViewById(R.id.zadacha3);



        zadacha12.setEnabled(false);
        zadacha13.setEnabled(false);


        CheckBox check1 = (CheckBox) findViewById(R.id.checkBox2);
        CheckBox check2 = (CheckBox) findViewById(R.id.checkBox3);
        CheckBox check3 = (CheckBox) findViewById(R.id.checkBox4);
        System.out.println(a);
        if (a == true) {
            System.out.println(a);
            check1.setChecked(true); // установит флажок в одно из состояний: true - активное, false - неактивное
            zadacha12.setEnabled(true);

        }
        if (a1 == true) {
            System.out.println(a);
            check1.setChecked(true); // установит флажок в одно из состояний: true - активное, false - неактивное
            check2.setChecked(true); // установит флажок в одно из состояний: true - активное, false - неактивное2
            zadacha12.setEnabled(true);
            zadacha13.setEnabled(true);
        }
        if (a2 == true) {
            System.out.println(a);
            check1.setChecked(true); // установит флажок в одно из состояний: true - активное, false - неактивное
            check2.setChecked(true); // установит флажок в одно из состояний: true - активное, false - неактивное2
            check3.setChecked(true); // установит флажок в одно из состояний: true - активное, false - неактивное2
            zadacha12.setEnabled(true);
            zadacha13.setEnabled(true);
            Intent intent = new Intent(Activity3.this, MainActivity.class);
            intent.putExtra("hello", 333);
            startActivity(intent);
        }



        View.OnClickListener oclBtnGoToSecAct3 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity3.this, zadacha1.class);
                startActivity(intent);
            }
        };
        zadacha11.setOnClickListener(oclBtnGoToSecAct3);


        View.OnClickListener oclBtnGoToSecAct5 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity3.this, zadacha3.class);
                startActivity(intent);
            }
        };
        zadacha13.setOnClickListener(oclBtnGoToSecAct5);


        View.OnClickListener oclBtnGoToSecAct4 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity3.this, zadacha2.class);
                startActivity(intent);
            }
        };
        zadacha12.setOnClickListener(oclBtnGoToSecAct4);


    }
}
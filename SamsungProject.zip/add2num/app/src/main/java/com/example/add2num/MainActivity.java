package com.example.add2num;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private EditText editText2;
    private TextView textView;
    private Button button;
    private Button button2;
    private Button button3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGoToSecAct = (Button) findViewById(R.id.btnGoToSecAct);
        Button button = (Button) findViewById(R.id.button2);


        View.OnClickListener oclBtnGoToSecAct = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, Activity_2.class);
                startActivity(intent);
            }
        };
        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);

        Button btnGoToSecAct2 = (Button) findViewById(R.id.btnGoToSecAct2);
        View.OnClickListener oclBtnGoToSecAct2 = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, Activity3.class);
                startActivity(intent);
            }
        };

        btnGoToSecAct2.setOnClickListener(oclBtnGoToSecAct2);




        button = findViewById(R.id.btnGoToSecAct2);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.btnGoToSecAct);
        button2.setEnabled(false);
        Bundle arguments = getIntent().getExtras();
        if (arguments != null) {
            String name = arguments.get("hello").toString();
            System.out.println(name.length());
            button2.setEnabled(true);


        }

        View.OnClickListener oclBtnGoToSecAct3 = new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(MainActivity.this, res.class);
                startActivity(intent);
            }
        };

        button2.setOnClickListener(oclBtnGoToSecAct3);




    }
}
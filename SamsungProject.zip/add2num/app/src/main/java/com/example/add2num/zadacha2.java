package com.example.add2num;

import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class zadacha2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zadacha2);
        Button btnGoToSecAct = (Button) findViewById(R.id.nazad);
        View.OnClickListener oclBtnGoToSecAct1 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(zadacha2.this, Activity3.class);
                startActivity(intent);
            }
        };

        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct1);

        TextView nickNameEditText = (TextView) findViewById(R.id.editTextTextPersonName);
        TextView naz = (TextView) findViewById(R.id.textView3);
        Button vern = (Button) findViewById(R.id.nazad);
        Button otpr = (Button) findViewById(R.id.button);
        nickNameEditText.setEnabled(false);


        Button proverka = (Button) findViewById(R.id.button);
        String[] a = {"один", "репутация", "Стрелец", "ответвление от серии", "устойчивый", "механический", "человек"};
        String[] a1 = {"", "", "", ""};
        String[] a2 = {"", "", ""};
        String[] a3 = {"", "", ""};
        String[] a4 = {"", "", "", ""};


        View.OnClickListener oclBtnGoToSecAct3 = new View.OnClickListener() {
            int i = -2;
            int i2 = -1;
            String a5 = "";
            boolean a6 = false;


            @Override
            public void onClick(View v) {
                i++;
                i2++;
                vern.setEnabled(false);
                nickNameEditText.setEnabled(true);
                otpr.setEnabled(true);

                int rnd = new Random().nextInt(a.length);
                a4[i2] = a[rnd];

                naz.setText(a[rnd]);
                System.out.println(i);

                if (i >= 0 && i < 3) {
                    if (a4[i2] == a4[i2 - 1]) {
                        a4[i2] = a[rnd];
                        naz.setText(a[rnd]);
                    }
                    String strCatName = nickNameEditText.getText().toString(); // приводим к типу String
                    a2[i] = strCatName;
                    a2[i] =a2[i].toLowerCase();
                    a2[i] = a2[i].trim();
                }
                if (a[rnd] == "один") {
                    a1[i2] = "alone";
                }
                if (a[rnd] == "человек") {
                    a1[i2] = "person";
                }
                if (a[rnd] == "репутация") {
                    a1[i2] = "reputation";
                }
                if (a[rnd] == "Стрелец") {
                    a1[i2] = "sagittarius";
                }
                if (a[rnd] == "ответвление от серии") {
                    a1[i2] = "spin-off";
                }
                if (a[rnd] == "устойчивый") {
                    a1[i2] = "steady";
                }
                if (a[rnd] == "механический") {
                    a1[i2] = "mechanic";
                } else if (i == 2) {
                    for (int i1 = 0; i1 < 3; i1++) {

                        if (a2[i1].equals(a1[i1])) {

                        } else {

                            a5 += ("вы ответили " + a2[i1] + ", а надо было " + a1[i1] + "\n");
                        }


                    }
                    naz.setText(a5);
                    if (a5 == "") {
                        vern.setEnabled(true);
                        vern.setText("Вернуться");
                        nickNameEditText.setEnabled(false);
                        otpr.setEnabled(false);
                        Intent intent = new Intent(zadacha2.this, Activity3.class);
                        intent.putExtra("hello", "22");
                        startActivity(intent);


                    } else {
                        vern.setText("повторите курс и вернитесь");
                        vern.setEnabled(true);
                        nickNameEditText.setEnabled(false);
                        otpr.setEnabled(false);
                        Intent intent = new Intent(zadacha2.this, Activity3.class);
                        intent.putExtra("hello", "2");


                    }
                }


            }

            ;
        };

        proverka.setOnClickListener(oclBtnGoToSecAct3);


    }

    ;
}

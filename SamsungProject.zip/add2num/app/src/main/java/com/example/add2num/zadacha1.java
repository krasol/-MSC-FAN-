package com.example.add2num;

import static com.example.add2num.R.id.gotoback;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Arrays;

public class zadacha1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zadacha1);
        TextView textView = findViewById(R.id.textView);


        final Button button1 = (Button) findViewById(R.id.button1);
        final Button button2 = (Button) findViewById(R.id.button2);

        final Button gotoback = (Button) findViewById(R.id.gotoback);
        View.OnClickListener onClickListener = new View.OnClickListener() {
            int over = -1;
            String[] cats = {"long - длинный?", "short - упрощенный?", "green - коричневый?", "will - вилка?", "who - лектор?", "hi - привет?", "нажмите на кнопку , чтобы увидеть результаты"};
            String[] a = {"1", "1", "1", "1", "1", "1", "1"};
            String[] a1 = {"ничего", "да", "нет", "нет", "нет", "нет", "да"};
            String a2 = "";

            basa dbHelper;

            @Override
            public void onClick(View view) {

                over += 1;
                if (over < 7) {
                    gotoback.setEnabled(false);

                    switch (view.getId()) {

                        case R.id.button1:
                            textView.setText(cats[over]);
                            a[over] = "да";
                            System.out.println(Arrays.deepToString(a));
                            break;

                        case R.id.button2:
                            textView.setText(cats[over]);
                            a[over] = "нет";
                            System.out.println(Arrays.deepToString(a));
                            break;

                    }
                } else {

                    gotoback.setEnabled(true);
                    button1.setEnabled(false);
                    button2.setEnabled(false);
                    gotoback.setText("вернуться и повторить курс");
                    System.out.println(Arrays.deepToString(a));
                    System.out.println(Arrays.deepToString(a1));

                    if (a1[1] == a[1] && a1[2] == a[2] && a1[3] == a[3] && a1[4] == a[4] && a1[5] == a[5] && a1[6] == a[6]) {
                        Intent intent = new Intent(zadacha1.this, Activity3.class);
                        intent.putExtra("hello", 1);
                        startActivity(intent);
                        SQLiteDatabase database = dbHelper.getWritableDatabase();



                        textView.setText("все правильно решили");
                        gotoback.setText("вернуться");


                    }
                    if (a1[1] != a[1]) {
                        a2 += "long - длинный, вы ответили: 'нет', правильно 'да'";

                        textView.setText(a2);
                    }
                    if (a1[2] != a[2]) {
                        a2 += "\nshort - упрощенный, вы ответили: 'да', правильно 'нет'";

                        textView.setText(a2);
                    }
                    if (a1[3] != a[3]) {
                        a2 += "\ngreen - коричневый, вы ответили: 'да', правильно 'нет'";

                        textView.setText(a2);
                    }
                    if (a1[4] != a[4]) {
                        a2 += "\nwill - вилка, вы ответили: 'да', правильно 'нет'";

                        textView.setText(a2);
                    }
                    if (a1[5] != a[5]) {
                        a2 += "\nwho - лектор, вы ответили: 'да', правильно 'нет'";

                        textView.setText(a2);
                    }
                    if (a1[6] != a[6]) {
                        a2 += "\nhi = привет, вы ответили: 'нет', правильно 'да'";

                        textView.setText(a2);
                    }
                }


            }
        };
        button1.setOnClickListener(onClickListener);
        button2.setOnClickListener(onClickListener);
        Button btnGoToSecAct = (Button) findViewById(R.id.gotoback);
        View.OnClickListener oclBtnGoToSecAct = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(zadacha1.this, Activity3.class);
                startActivity(intent);
            }
        };
        btnGoToSecAct.setOnClickListener(oclBtnGoToSecAct);


    }

}